cd ..
javadoc -cp "./lib/*" ./src/main/java/*.java -d ./docs/javadoc